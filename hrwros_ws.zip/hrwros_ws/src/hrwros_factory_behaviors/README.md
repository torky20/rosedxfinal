# hrwros_factory_behaviors
This folder contains all states and behaviors for the factory simulation of the MOOC "Hello (Real) World with ROS.
It includes some states from the flexbe repository and from the generic_flexbe_states repository.
